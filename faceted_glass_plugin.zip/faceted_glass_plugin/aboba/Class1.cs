﻿namespace aboba
{
    public class Class1
    {

    }
}
