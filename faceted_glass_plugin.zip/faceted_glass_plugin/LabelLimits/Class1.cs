﻿namespace LabelLimits
{
    public class Class1
    {

    }
}
